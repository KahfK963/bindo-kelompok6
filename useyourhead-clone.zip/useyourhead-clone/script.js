// Sample product data for this learning prototype.
// Replace these demo products and image URLs with authorized product assets.
const products = [
  {
    id: 1,
    name: "011 Think Less Feel More",
    price: 350000,
    image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=900&q=85"
  },
  {
    id: 2,
    name: "Running Essential",
    price: 300000,
    image: "https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=900&q=85"
  },
  {
    id: 3,
    name: "Everyday Headwear",
    price: 275000,
    image: "https://images.unsplash.com/photo-1575428652377-a2d80e2277_fc?auto=format&fit=crop&w=900&q=85"
  }
];

let cart = [];

const formatRupiah = (amount) =>
  new Intl.NumberFormat("id-ID").format(amount);

function renderProducts() {
  const container = document.getElementById("products");

  container.innerHTML = products.map((product) => `
    <article class="product">
      <img src="${product.image}" alt="${product.name}" loading="lazy">
      <div class="product-info">
        <h3>${product.name}</h3>
        <p class="product-price">Rp ${formatRupiah(product.price)}</p>
      </div>
      <button class="button button-dark" type="button"
        onclick="addToCart(${product.id})">ADD TO CART</button>
    </article>
  `).join("");
}

function addToCart(id) {
  const product = products.find((item) => item.id === id);
  if (!product) return;

  const existingItem = cart.find((item) => item.id === id);
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ ...product, quantity: 1 });
  }

  renderCart();
}

function removeItem(id) {
  cart = cart.filter((item) => item.id !== id);
  renderCart();
}

function renderCart() {
  const container = document.getElementById("cart-items");

  if (cart.length === 0) {
    container.innerHTML = '<p class="empty-cart">Your cart is empty.</p>';
  } else {
    container.innerHTML = cart.map((item) => `
      <div class="cart-row">
        <div>
          <p>${item.name}</p>
          <small>${item.quantity} × Rp ${formatRupiah(item.price)}</small>
        </div>
        <div>
          <strong>Rp ${formatRupiah(item.price * item.quantity)}</strong>
          <button class="remove-button" type="button"
            onclick="removeItem(${item.id})">Remove</button>
        </div>
      </div>
    `).join("");
  }

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity, 0
  );
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  document.getElementById("total").textContent = formatRupiah(total);
  document.getElementById("cart-count").textContent = itemCount;
}

function checkout() {
  if (cart.length === 0) {
    alert("Your cart is empty!");
    return;
  }

  alert(
    "Demo checkout only. A real checkout requires a secure backend, " +
    "server-side price validation, and payment gateway integration."
  );
}

document.getElementById("checkout-button")
  .addEventListener("click", checkout);

renderProducts();
renderCart();
