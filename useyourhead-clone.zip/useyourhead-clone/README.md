# USE YOUR HEAD — Learning Prototype

A small, responsive e-commerce frontend inspired by the general sports-headwear storefront concept of useyourhead.id.

This is an independent learning recreation, not the original website source code and not affiliated with the brand.

## Files

- `index.html` — page structure
- `style.css` — layout and responsive styling
- `script.js` — sample products and shopping cart interactions

## Run locally

1. Extract the ZIP file.
2. Open the `useyourhead-clone` folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the Live Server extension.
4. Ensure you have an internet connection to load the demo product images.

## Included

- Responsive navigation
- Hero section
- Sample product catalogue
- Add-to-cart functionality
- Remove-from-cart functionality
- Automatic cart count and total calculation

## Not included

- PHP backend
- MySQL database
- User authentication
- Real order processing
- Midtrans integration

The checkout button is a demo only. Do not use this prototype to accept real payments. A production implementation needs a secure backend, server-side validation, and payment gateway integration.
