# USE YOUR HEAD — upgraded storefront prototype

Independent front-end learning prototype. This is not the original source code of useyourhead.id and is not affiliated with the brand.

## Run
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open `index.html` in a browser, or run with VS Code Live Server.
4. Product images and Google Fonts use remote URLs, so an internet connection is needed for those assets.

## Features implemented
- New visual identity and responsive navigation/menu
- Product catalogue with category filters
- Product search
- Sorting: featured, price low-to-high, price high-to-low, and name A–Z
- Add to bag, increase/decrease quantity, remove items
- Cart count, subtotal, shipping fee, discount, and total calculation
- Cart persistence using browser localStorage
- Demo coupon `HEAD10` for 10% off subtotal
- Checkout form with name, email, phone, address
- Shipping options: Regular and Express
- Payment method choices: bank transfer, virtual account, QRIS, e-wallet, COD (demo only)
- Demo order confirmation
- Shipping information, contact information, and expanded About Us section
- Mobile responsive layout

## Important production notes
- This is a front-end-only demo. Checkout does not create a real order.
- No real payment is collected. Payment methods are selectable UI demonstrations only.
- Shipping rates and delivery estimates are placeholders; no courier API is connected.
- Contact number, email, and address are sample placeholders. Replace them with verified official business details.
- For production, build a secure backend, database, authentication if needed, server-side cart/price validation, real order management, courier integration, and a trusted payment gateway such as a properly configured provider account.
- Do not put payment secrets or API keys in browser JavaScript.
