const products = [
  {id:1,name:"011 Think Less Feel More",category:"cap",categoryLabel:"Signature cap",price:350000,tag:"BEST SELLER",image:"https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=900&q=85"},
  {id:2,name:"Running Essential",category:"cap",categoryLabel:"Performance cap",price:300000,tag:"EVERYDAY",image:"https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=900&q=85"},
  {id:3,name:"Everyday Headwear",category:"cap",categoryLabel:"Classic cap",price:275000,tag:"",image:"https://images.unsplash.com/photo-1575428652377-a2d80e2277fc?auto=format&fit=crop&w=900&q=85"},
  {id:4,name:"After Hours Beanie",category:"beanie",categoryLabel:"Knit beanie",price:225000,tag:"NEW DROP",image:"https://images.unsplash.com/photo-1576871337622-98d48d1cf531?auto=format&fit=crop&w=900&q=85"},
  {id:5,name:"Off Grid Beanie",category:"beanie",categoryLabel:"Daily beanie",price:250000,tag:"",image:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=900&q=85"},
  {id:6,name:"U/YH Utility Tote",category:"accessory",categoryLabel:"Daily accessory",price:175000,tag:"",image:"https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=900&q=85"}
];
const SHIPPING = {regular:20000,express:35000};
const formatRupiah = value => "Rp " + new Intl.NumberFormat("id-ID").format(value);
let cart = loadCart();
let activeCategory = "all";
let appliedCoupon = false;
let shippingCost = SHIPPING.regular;
let toastTimer;

function loadCart(){try{return JSON.parse(localStorage.getItem("uyh-cart"))||[]}catch{return []}}
function saveCart(){localStorage.setItem("uyh-cart",JSON.stringify(cart))}
function showToast(message){const el=document.getElementById("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2200)}
function renderProducts(){
  const search=document.getElementById("search-input").value.trim().toLowerCase();
  const sort=document.getElementById("sort-select").value;
  let list=products.filter(p=>(activeCategory==="all"||p.category===activeCategory)&&(p.name.toLowerCase().includes(search)||p.categoryLabel.toLowerCase().includes(search)));
  if(sort==="price-asc")list.sort((a,b)=>a.price-b.price);
  if(sort==="price-desc")list.sort((a,b)=>b.price-a.price);
  if(sort==="name")list.sort((a,b)=>a.name.localeCompare(b.name));
  document.getElementById("result-count").textContent=`Showing ${list.length} of ${products.length} pieces`;
  document.getElementById("products").innerHTML=list.length?list.map(p=>`
    <article class="product"><div class="product-image-wrap">
      <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='https://placehold.co/700x750/e6e5dc/171914?text=USE+YOUR+HEAD'">
      ${p.tag?`<span class="product-tag">${p.tag}</span>`:""}
      <button class="quick-add" type="button" onclick="addToCart(${p.id})">＋ ADD TO BAG</button>
    </div><div class="product-info"><div><h3>${p.name}</h3><p class="product-category">${p.categoryLabel}</p></div><p class="product-price">${formatRupiah(p.price)}</p></div></article>`).join(""):`<p class="empty-products">No pieces found. Try another search or category.</p>`;
  document.getElementById("all-count").textContent=String(products.length).padStart(2,"0");
}
function addToCart(id){const p=products.find(x=>x.id===id);if(!p)return;const item=cart.find(x=>x.id===id);if(item)item.quantity++;else cart.push({...p,quantity:1});saveCart();renderCart();showToast(`${p.name} added to your bag`)}
function changeQty(id,delta){const item=cart.find(x=>x.id===id);if(!item)return;item.quantity+=delta;if(item.quantity<=0)cart=cart.filter(x=>x.id!==id);saveCart();renderCart()}
function removeItem(id){cart=cart.filter(x=>x.id!==id);saveCart();renderCart();showToast("Item removed")}
function getSubtotal(){return cart.reduce((sum,item)=>sum+item.price*item.quantity,0)}
function getDiscount(){return appliedCoupon?Math.round(getSubtotal()*.1):0}
function getTotal(){return Math.max(0,getSubtotal()+ (cart.length?shippingCost:0)-getDiscount())}
function renderCart(){
  const container=document.getElementById("cart-items");
  if(!cart.length){container.innerHTML='<p class="empty-cart">Your bag is still empty. Explore the collection and find your piece. ↗</p>';}
  else{container.innerHTML=cart.map(item=>`<article class="cart-item"><img src="${item.image}" alt="${item.name}"><div><h3>${item.name}</h3><small>${item.categoryLabel} · ${formatRupiah(item.price)}</small><div class="qty-control"><button type="button" aria-label="Kurangi jumlah" onclick="changeQty(${item.id},-1)">−</button><span>${item.quantity}</span><button type="button" aria-label="Tambah jumlah" onclick="changeQty(${item.id},1)">＋</button></div></div><div class="cart-item-end"><strong>${formatRupiah(item.price*item.quantity)}</strong><button class="remove-button" type="button" onclick="removeItem(${item.id})">Remove</button></div></article>`).join("")}
  const count=cart.reduce((s,i)=>s+i.quantity,0);
  document.getElementById("cart-count").textContent=count;
  document.getElementById("subtotal").textContent=formatRupiah(getSubtotal());
  document.getElementById("shipping-cost").textContent=formatRupiah(cart.length?shippingCost:0);
  document.getElementById("discount").textContent="- "+formatRupiah(getDiscount());
  document.getElementById("total").textContent=formatRupiah(getTotal());
  document.getElementById("coupon-message").textContent=appliedCoupon?"HEAD10 applied — 10% off your subtotal.":"";
}
function applyCoupon(){const value=document.getElementById("coupon-input").value.trim().toUpperCase();if(value==="HEAD10"){appliedCoupon=true;renderCart();showToast("Promo HEAD10 applied")}else{appliedCoupon=false;renderCart();document.getElementById("coupon-message").textContent="Kode promo tidak valid. Coba HEAD10.";document.getElementById("coupon-message").style.color="#b34b35"}}
function openCheckout(){
  if(!cart.length){showToast("Your bag is empty");return}
  document.getElementById("checkout-shipping").value=String(shippingCost);
  renderCheckoutSummary();
  document.getElementById("checkout-dialog").showModal();
}
function renderCheckoutSummary(){
  const shipping=Number(document.getElementById("checkout-shipping").value||shippingCost);
  const total=Math.max(0,getSubtotal()+shipping-getDiscount());
  document.getElementById("checkout-items").innerHTML=cart.map(i=>`<div class="checkout-order-item"><span>${i.name} × ${i.quantity}</span><span>${formatRupiah(i.price*i.quantity)}</span></div>`).join("");
  document.getElementById("checkout-total").textContent=formatRupiah(total);
}
function submitDemoOrder(event){
  event.preventDefault();
  if(!cart.length)return;
  const form=new FormData(event.currentTarget);
  const name=String(form.get("name")).trim();
  const email=String(form.get("email")).trim();
  const address=String(form.get("address")).trim();
  if(!name||!email||!address){showToast("Please complete the required fields");return}
  const orderCode="UYH-"+Date.now().toString().slice(-7);
  document.getElementById("checkout-dialog").close();
  document.getElementById("success-message").textContent=`Thank you, ${name}. Demo order ${orderCode} has been prepared. Ringkasan pesanan hanya ditampilkan di browser dan tidak dikirim ke toko.`;
  document.getElementById("success-dialog").showModal();
  cart=[];appliedCoupon=false;saveCart();renderCart();event.currentTarget.reset();
}
document.querySelectorAll(".filter").forEach(button=>button.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));button.classList.add("active");activeCategory=button.dataset.category;renderProducts()}));
document.getElementById("search-input").addEventListener("input",renderProducts);
document.getElementById("sort-select").addEventListener("change",renderProducts);
document.getElementById("apply-coupon").addEventListener("click",applyCoupon);
document.getElementById("checkout-button").addEventListener("click",openCheckout);
document.getElementById("checkout-shipping").addEventListener("change",event=>{shippingCost=Number(event.target.value);renderCheckoutSummary()});
document.getElementById("checkout-form").addEventListener("submit",submitDemoOrder);
document.getElementById("close-dialog").addEventListener("click",()=>document.getElementById("checkout-dialog").close());
document.getElementById("finish-order").addEventListener("click",()=>document.getElementById("success-dialog").close());
document.getElementById("menu-toggle").addEventListener("click",()=>{const nav=document.getElementById("main-nav");const open=nav.classList.toggle("open");document.getElementById("menu-toggle").setAttribute("aria-expanded",String(open))});
document.querySelectorAll("#main-nav a").forEach(a=>a.addEventListener("click",()=>{document.getElementById("main-nav").classList.remove("open");document.getElementById("menu-toggle").setAttribute("aria-expanded","false")}));
renderProducts();renderCart();
